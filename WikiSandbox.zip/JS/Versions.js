const preclassic = []
const classic = ["c0.0.11a.json", "c0.0.12a.json"]
const indev = []
const infdev = []
const alpha = []
const beta = []
const release = []

let versions = preclassic.concat(classic).concat(infdev).concat(indev).concat(alpha).concat(beta).concat(release)